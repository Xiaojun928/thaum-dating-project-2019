#!/bin/bash
#SBATCH -n 1
time /home-user/xyfeng/database/paml/paml4.9h/src/mcmctree 04_mcmctree.ctl
