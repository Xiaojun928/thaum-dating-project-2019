#!/bin/bash
#SBATCH -n 1
cd tmp0030
/home-user/xyfeng/database/paml/paml4.9h/src/codeml tmp0030.ctl
