#!/bin/bash
#SBATCH -n 1
cd tmp0074
/home-user/xyfeng/database/paml/paml4.9h/src/codeml tmp0074.ctl
